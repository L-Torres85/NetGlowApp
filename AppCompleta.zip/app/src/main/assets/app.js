document.addEventListener('DOMContentLoaded', () => {
  const appContainer = document.getElementById('app-container');
  const widgetBtn = document.getElementById('widget-mode-btn');
  const noteWindow = document.getElementById('note-window');
  const killSwitch = document.getElementById('kill-switch-btn');
  const noteInput = document.getElementById('note-input');
  const topBar = document.querySelector('.top-bar');
  const controlPanel = document.querySelector('.control-panel');

  let isWidgetMode = false;

  // 1. NAVEGACIÓN ENTRE PESTAÑAS (Texto, Fx, Bloc, 3D)
  const navBtns = document.querySelectorAll('.nav-btn');
  const settingsGroups = document.querySelectorAll('.settings-group');

  navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      navBtns.forEach(b => b.classList.remove('active'));
      settingsGroups.forEach(g => g.classList.remove('active'));
      btn.classList.add('active');
      const catId = btn.getAttribute('data-cat');
      document.getElementById(catId).classList.add('active');
    });
  });

  // 2. MODO WIDGET Y DOBLE TOQUE
  widgetBtn.addEventListener('click', () => {
    isWidgetMode = true;
    appContainer.classList.remove('editor-mode');
    appContainer.classList.add('widget-mode');
    topBar.style.display = 'none';
    controlPanel.style.display = 'none';
    noteInput.style.pointerEvents = 'none';

    if (window.AndroidBridge) {
      const rect = noteWindow.getBoundingClientRect();
      window.AndroidBridge.cambiarTamano(true, Math.ceil(rect.width) + 40, Math.ceil(rect.height) + 40);
    }
  });

  noteWindow.addEventListener('dblclick', () => {
    if (!isWidgetMode) return;
    isWidgetMode = false;
    appContainer.classList.remove('widget-mode');
    appContainer.classList.add('editor-mode');
    topBar.style.display = '';
    controlPanel.style.display = '';
    noteInput.style.pointerEvents = 'auto';

    if (window.AndroidBridge) {
      window.AndroidBridge.cambiarTamano(false, 0, 0);
    }
  });

  killSwitch.addEventListener('click', (e) => {
    e.stopPropagation();
    if (window.AndroidBridge) window.AndroidBridge.cerrarApp();
  });
  killSwitch.addEventListener('dblclick', (e) => e.stopPropagation());

  // 3. MOTOR UNIFICADO DE TEXTO (Sólido, Degradado, Neón, Stroke)
  const textR = document.getElementById('text-r');
  const textG = document.getElementById('text-g');
  const textB = document.getElementById('text-b');
  const textColorPreview = document.getElementById('text-color-preview');
  const fontSizeSlider = document.getElementById('font-size-slider');
  const valFontSize = document.getElementById('val-font-size');
  const fontWeightSlider = document.getElementById('font-weight-slider');
  const valFontWeight = document.getElementById('val-font-weight');
  const strokeToggle = document.getElementById('stroke-toggle');
  const strokeColor = document.getElementById('stroke-color');
  const strokeWidthSlider = document.getElementById('stroke-width-slider');
  const valStrokeWidth = document.getElementById('val-stroke-width');
  const alignSelect = document.getElementById('align-select');

  const textGradToggle = document.getElementById('text-grad-toggle');
  const textGradC1 = document.getElementById('text-grad-c1');
  const textGradC2 = document.getElementById('text-grad-c2');
  const textGlowColor = document.getElementById('text-glow-color');
  const textGlowBlur = document.getElementById('text-glow-blur');
  const valTextGlow = document.getElementById('val-text-glow');

  function updateTextStyles() {
    const r = textR.value, g = textG.value, b = textB.value;
    const solidColor = `rgb(${r}, ${g}, ${b})`;
    textColorPreview.style.backgroundColor = solidColor;

    valFontSize.innerText = `${fontSizeSlider.value}px`;
    noteInput.style.fontSize = `${fontSizeSlider.value}px`;

    valFontWeight.innerText = fontWeightSlider.value;
    noteInput.style.fontWeight = fontWeightSlider.value;

    noteInput.style.textAlign = alignSelect.value;

    if (strokeToggle.checked) {
      valStrokeWidth.innerText = `${strokeWidthSlider.value}px`;
      noteInput.style.webkitTextStroke = `${strokeWidthSlider.value}px ${strokeColor.value}`;
    } else {
      noteInput.style.webkitTextStroke = '0px transparent';
    }

    // Degradado vs Sólido
    if (textGradToggle.checked) {
      noteInput.style.backgroundImage = `linear-gradient(45deg, ${textGradC1.value}, ${textGradC2.value})`;
      noteInput.style.webkitBackgroundClip = 'text';
      noteInput.style.webkitTextFillColor = 'transparent';
    } else {
      noteInput.style.backgroundImage = 'none';
      noteInput.style.webkitBackgroundClip = 'initial';
      noteInput.style.webkitTextFillColor = solidColor;
      noteInput.style.color = solidColor;
    }

    // Brillo Neón
    const blurVal = parseInt(textGlowBlur.value);
    valTextGlow.innerText = `${blurVal}px`;
    if (blurVal > 0) {
      const gColor = textGlowColor.value;
      noteInput.style.filter = `drop-shadow(0px 0px ${blurVal}px ${gColor}) drop-shadow(0px 0px ${Math.floor(blurVal/2)}px ${gColor})`;
    } else {
      noteInput.style.filter = 'none';
    }
  }

  [textR, textG, textB, fontSizeSlider, fontWeightSlider, strokeToggle, strokeColor, strokeWidthSlider, alignSelect, textGradToggle, textGradC1, textGradC2, textGlowColor, textGlowBlur]
    .forEach(el => el.addEventListener('input', updateTextStyles));

  // 4. MOTOR DE BLOC Y VIDRIO (Forma, Opacidad, Degradado, Sombra)
  const glassR = document.getElementById('glass-r');
  const glassG = document.getElementById('glass-g');
  const glassB = document.getElementById('glass-b');
  const boxOpacitySlider = document.getElementById('box-opacity-slider');
  const valBoxOpacity = document.getElementById('val-box-opacity');
  const shapeBtns = document.querySelectorAll('.option-btn[data-shape]');

  const gradientToggle = document.getElementById('gradient-toggle');
  const gradBtns = document.querySelectorAll('.grad-btn');
  const gradR1 = document.getElementById('grad-r1'), gradG1 = document.getElementById('grad-g1'), gradB1 = document.getElementById('grad-b1');
  const gradR2 = document.getElementById('grad-r2'), gradG2 = document.getElementById('grad-g2'), gradB2 = document.getElementById('grad-b2');
  const gradPosSlider = document.getElementById('grad-pos-slider');
  const valGradPos = document.getElementById('val-grad-pos');

  const shadowToggle = document.getElementById('shadow-toggle');
  const shadowR = document.getElementById('shadow-r'), shadowG = document.getElementById('shadow-g'), shadowB = document.getElementById('shadow-b');
  const shadowSpread = document.getElementById('shadow-spread'), shadowBlur = document.getElementById('shadow-blur');
  const valShadowSpread = document.getElementById('val-shadow-spread'), valShadowBlur = document.getElementById('val-shadow-blur');

  let currentShape = 'shape-rounded';
  let gradStyle = 'linear';

  shapeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      shapeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      noteWindow.classList.remove(currentShape);
      currentShape = btn.getAttribute('data-shape');
      noteWindow.classList.add(currentShape);
    });
  });

  gradBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      gradBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      gradStyle = btn.getAttribute('data-style');
      updateBlocStyles();
    });
  });

  function updateBlocStyles() {
    const opacity = boxOpacitySlider.value / 100;
    valBoxOpacity.innerText = `${boxOpacitySlider.value}%`;

    if (gradientToggle.checked) {
      valGradPos.innerText = `${gradPosSlider.value}°`;
      const c1 = `rgba(${gradR1.value}, ${gradG1.value}, ${gradB1.value}, ${opacity})`;
      const c2 = `rgba(${gradR2.value}, ${gradG2.value}, ${gradB2.value}, ${opacity})`;
      if (gradStyle === 'radial') {
        noteWindow.style.background = `radial-gradient(circle, ${c1}, ${c2})`;
      } else if (gradStyle === 'center') {
        noteWindow.style.background = `radial-gradient(ellipse at center, ${c1}, ${c2})`;
      } else {
        noteWindow.style.background = `linear-gradient(${gradPosSlider.value}deg, ${c1}, ${c2})`;
      }
    } else {
      noteWindow.style.background = `rgba(${glassR.value}, ${glassG.value}, ${glassB.value}, ${opacity})`;
    }

    if (shadowToggle.checked) {
      valShadowSpread.innerText = `${shadowSpread.value}px`;
      valShadowBlur.innerText = `${shadowBlur.value}px`;
      const sColor = `rgba(${shadowR.value}, ${shadowG.value}, ${shadowB.value}, 0.6)`;
      noteWindow.style.boxShadow = `0px 0px ${shadowBlur.value}px ${shadowSpread.value}px ${sColor}`;
    } else {
      noteWindow.style.boxShadow = 'none';
    }
  }

  [glassR, glassG, glassB, boxOpacitySlider, gradientToggle, gradR1, gradG1, gradB1, gradR2, gradG2, gradB2, gradPosSlider, shadowToggle, shadowR, shadowG, shadowB, shadowSpread, shadowBlur]
    .forEach(el => el.addEventListener('input', updateBlocStyles));

  // 5. MOTOR 3D Y WARP (Escala, Posición, Giros X/Y/Z)
  const boxScaleSlider = document.getElementById('box-scale-slider');
  const valBoxScale = document.getElementById('val-box-scale');
  const boxPosX = document.getElementById('box-pos-x');
  const valBoxX = document.getElementById('val-box-x');
  const boxPosY = document.getElementById('box-pos-y');
  const valBoxY = document.getElementById('val-box-y');

  const warpToggle = document.getElementById('warp-toggle');
  const warpX = document.getElementById('warp-x');
  const warpY = document.getElementById('warp-y');
  const warpZ = document.getElementById('warp-z');

  function update3D() {
    const scale = boxScaleSlider.value / 100;
    valBoxScale.innerText = `${boxScaleSlider.value}%`;
    valBoxX.innerText = `${boxPosX.value}px`;
    valBoxY.innerText = `${boxPosY.value}px`;

    let transformStr = `scale(${scale}) translate(${boxPosX.value}px, ${boxPosY.value}px)`;

    if (warpToggle.checked) {
      transformStr += ` rotateX(${warpX.value}deg) rotateY(${warpY.value}deg) rotateZ(${warpZ.value}deg)`;
    }

    noteWindow.style.transform = transformStr;
  }

  [boxScaleSlider, boxPosX, boxPosY, warpToggle, warpX, warpY, warpZ]
    .forEach(el => el.addEventListener('input', update3D));

  // Inicialización
  updateTextStyles();
  updateBlocStyles();
  update3D();
});
