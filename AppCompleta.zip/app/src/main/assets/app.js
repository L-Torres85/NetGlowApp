document.addEventListener('DOMContentLoaded', () => {
  const toggleWallpaperBtn = document.getElementById('toggle-wallpaper-btn');
  const appContainer = document.getElementById('app-container');
  const noteWindow = document.getElementById('note-window');
  const noteInput = document.getElementById('note-input');

  const navBtns = document.querySelectorAll('.category-nav .nav-btn');
  const catGroups = document.querySelectorAll('.settings-group');

  navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      navBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const targetCat = btn.getAttribute('data-cat');
      catGroups.forEach(g => {
        g.classList.remove('active');
        if (g.id === targetCat) g.classList.add('active');
      });
    });
  });

  const textR = document.getElementById('text-r'), textG = document.getElementById('text-g'), textB = document.getElementById('text-b');
  const textColorPreview = document.getElementById('text-color-preview');
  const fontSizeSlider = document.getElementById('font-size-slider'), valFontSize = document.getElementById('val-font-size');
  const fontWeightSlider = document.getElementById('font-weight-slider'), valFontWeight = document.getElementById('val-font-weight');
  const strokeToggle = document.getElementById('stroke-toggle'), strokeColor = document.getElementById('stroke-color'), strokeWidthSlider = document.getElementById('stroke-width-slider'), valStrokeWidth = document.getElementById('val-stroke-width');
  const alignSelectEl = document.getElementById('align-select');
  
  const chromaticToggle = document.getElementById('chromatic-toggle'), chromaticSlider = document.getElementById('chromatic-slider'), valChromatic = document.getElementById('val-chromatic');
  const tshadowToggle = document.getElementById('tshadow-toggle'), tshadowDepthSlider = document.getElementById('tshadow-depth-slider'), tshadowBlurSlider = document.getElementById('tshadow-blur-slider'), tshadowAngleSlider = document.getElementById('tshadow-angle-slider'), tshadowColor = document.getElementById('tshadow-color'), valTshadowDepth = document.getElementById('val-tshadow-depth'), valTshadowBlur = document.getElementById('val-tshadow-blur'), valTshadowAngle = document.getElementById('val-tshadow-angle');
  const staticToggle = document.getElementById('static-toggle'), staticGrainSlider = document.getElementById('static-grain-slider'), staticBlendSlider = document.getElementById('static-blend-slider'), valStaticGrain = document.getElementById('val-static-grain'), valStaticBlend = document.getElementById('val-static-blend');
  const dissolveToggle = document.getElementById('dissolve-toggle'), dissolveSizeSlider = document.getElementById('dissolve-size-slider'), dissolveStretchSlider = document.getElementById('dissolve-stretch-slider'), dissolveFadeSlider = document.getElementById('dissolve-fade-slider'), valDissolveSize = document.getElementById('val-dissolve-size'), valDissolveStretch = document.getElementById('val-dissolve-stretch'), valDissolveFade = document.getElementById('val-dissolve-fade');
  const crtToggle = document.getElementById('crt-toggle'), crtScanlineSlider = document.getElementById('crt-scanline-slider'), crtJitterSlider = document.getElementById('crt-jitter-slider'), valCrtScanline = document.getElementById('val-crt-scanline'), valCrtJitter = document.getElementById('val-crt-jitter');

  const shapeBtns = document.querySelectorAll('.option-btn[data-shape]');
  const glassR = document.getElementById('glass-r'), glassG = document.getElementById('glass-g'), glassB = document.getElementById('glass-b'), boxOpacitySlider = document.getElementById('box-opacity-slider'), valBoxOpacity = document.getElementById('val-box-opacity');
  const gradientToggle = document.getElementById('gradient-toggle'), gradBtns = document.querySelectorAll('.grad-btn'), gradR1 = document.getElementById('grad-r1'), gradG1 = document.getElementById('grad-g1'), gradB1 = document.getElementById('grad-b1'), gradR2 = document.getElementById('grad-r2'), gradG2 = document.getElementById('grad-g2'), gradB2 = document.getElementById('grad-b2'), gradPosSlider = document.getElementById('grad-pos-slider'), valGradPos = document.getElementById('val-grad-pos');
  const fadeToggle = document.getElementById('fade-toggle'), fadeBtns = document.querySelectorAll('.fade-btn'), fadeDirSlider = document.getElementById('fade-dir-slider'), fadeRangeSlider = document.getElementById('fade-range-slider'), fadeIntensitySlider = document.getElementById('fade-intensity-slider'), valFadeDir = document.getElementById('val-fade-dir'), valFadeRange = document.getElementById('val-fade-range'), valFadeIntensity = document.getElementById('val-fade-intensity');
  const shadowToggle = document.getElementById('shadow-toggle'), shadowR = document.getElementById('shadow-r'), shadowG = document.getElementById('shadow-g'), shadowB = document.getElementById('shadow-b'), shadowSpread = document.getElementById('shadow-spread'), shadowBlur = document.getElementById('shadow-blur'), valShadowSpread = document.getElementById('val-shadow-spread'), valShadowBlur = document.getElementById('val-shadow-blur');
  
  const boxScaleSlider = document.getElementById('box-scale-slider'), boxPosX = document.getElementById('box-pos-x'), boxPosY = document.getElementById('box-pos-y'), valBoxScale = document.getElementById('val-box-scale'), valBoxPosX = document.getElementById('val-box-x'), valBoxPosY = document.getElementById('val-box-y');
  const warpToggle = document.getElementById('warp-toggle'), warpBtns = document.querySelectorAll('.warp-btn'), warpX = document.getElementById('warp-x'), warpY = document.getElementById('warp-y'), warpZ = document.getElementById('warp-z'), warpIntensity = document.getElementById('warp-intensity'), valWarpIntensity = document.getElementById('val-warp-intensity');

  let currentGradStyle = 'linear', currentFadeStyle = 'linear', currentWarpStyle = 'arc';

  let wallpaperIndex = 1;
  toggleWallpaperBtn.addEventListener('click', () => {
    appContainer.classList.remove(`wallpaper-preview-${wallpaperIndex}`);
    wallpaperIndex = wallpaperIndex >= 3 ? 1 : wallpaperIndex + 1;
    appContainer.classList.add(`wallpaper-preview-${wallpaperIndex}`);
  });

  function updateTextStyling() {
    const rgbString = `rgb(${textR.value}, ${textG.value}, ${textB.value})`;
    noteInput.style.color = rgbString;
    textColorPreview.style.backgroundColor = rgbString;

    const fWeight = fontWeightSlider.value;
    valFontWeight.textContent = fWeight;
    noteInput.style.fontWeight = fWeight;

    if (strokeToggle.checked) {
      const sWidth = parseFloat(strokeWidthSlider.value);
      const sColor = strokeColor.value;
      valStrokeWidth.textContent = sWidth;
      noteInput.style.webkitTextStroke = `${sWidth * 2}px ${sColor}`;
      noteInput.style.paintOrder = 'stroke fill';
    } else {
      noteInput.style.webkitTextStroke = '0px transparent';
      noteInput.style.paintOrder = 'normal';
    }

    let combinedShadows = [];

    const chromVal = parseInt(chromaticSlider.value);
    valChromatic.textContent = chromVal;
    if (chromaticToggle.checked && chromVal > 0) {
      const blurVal = (chromVal * 0.4).toFixed(1);
      combinedShadows.push(`${-chromVal}px 0px ${blurVal}px rgba(255, 0, 90, 0.6)`);
      combinedShadows.push(`${chromVal}px 0px ${blurVal}px rgba(0, 200, 255, 0.6)`);
    }

    const depth = parseInt(tshadowDepthSlider.value); valTshadowDepth.textContent = depth;
    const blurAmount = parseInt(tshadowBlurSlider.value); valTshadowBlur.textContent = blurAmount;
    const angleDeg = parseInt(tshadowAngleSlider.value); valTshadowAngle.textContent = angleDeg;
    
    if (tshadowToggle.checked) {
      const angleRad = angleDeg * (Math.PI / 180);
      const dx = (depth * Math.cos(angleRad)).toFixed(1);
      const dy = (depth * Math.sin(angleRad)).toFixed(1);
      combinedShadows.push(`${dx}px ${dy}px ${blurAmount}px ${tshadowColor.value}`);
    }
    
    noteInput.style.textShadow = combinedShadows.length > 0 ? combinedShadows.join(', ') : 'none';

    const isStaticActive = staticToggle.checked;
    const isDissolveActive = dissolveToggle.checked;
    const isCrtActive = crtToggle.checked;

    const grainVal = parseFloat(staticGrainSlider.value); valStaticGrain.textContent = grainVal;
    const blendVal = parseInt(staticBlendSlider.value); valStaticBlend.textContent = blendVal;
    const sizeVal = parseFloat(dissolveSizeSlider.value); valDissolveSize.textContent = sizeVal;
    const stretchVal = parseInt(dissolveStretchSlider.value); valDissolveStretch.textContent = stretchVal;
    const fadeVal = parseInt(dissolveFadeSlider.value); valDissolveFade.textContent = fadeVal;
    const scanVal = parseInt(crtScanlineSlider.value); valCrtScanline.textContent = scanVal;
    const jitterVal = parseInt(crtJitterSlider.value); valCrtJitter.textContent = jitterVal;

    if (isStaticActive || isDissolveActive || isCrtActive) {
      const tileS = 400; const displayS = 200; 
      const canvas = document.createElement('canvas'); canvas.width = tileS; canvas.height = tileS;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#000000'; ctx.fillRect(0, 0, tileS, tileS);
      ctx.globalCompositeOperation = 'destination-out';

      if (isStaticActive) {
        const blockW = Math.max(0.5, grainVal); 
        const intensity = blendVal / 100;
        ctx.fillStyle = `rgba(0,0,0,${intensity})`; 
        for(let y = 0; y < tileS; y += blockW) {
          for(let x = 0; x < tileS; x += blockW) {
            if (Math.random() < 0.5) ctx.fillRect(x, y, blockW, blockW);
          }
        }
      }

      if (isDissolveActive) {
        const blockW = Math.max(0.5, sizeVal); 
        const blockH = Math.max(0.5, blockW * stretchVal);
        const fadeThreshold = fadeVal / 100;
        ctx.fillStyle = 'rgba(0,0,0,1)';
        for(let y = 0; y < tileS; y += blockH) {
          for(let x = 0; x < tileS; x += blockW) {
            if (Math.random() < fadeThreshold) ctx.fillRect(x, y, blockW, blockH);
          }
        }
      }

      if (isCrtActive) {
        ctx.fillStyle = 'rgba(0,0,0,0.5)'; 
        for(let y = 0; y < tileS; y += (scanVal * 2)) ctx.fillRect(0, y, tileS, scanVal);
      }

      const encodedPng = canvas.toDataURL('image/png');
      noteInput.style.webkitMaskImage = `url("${encodedPng}")`; noteInput.style.maskImage = `url("${encodedPng}")`;
      noteInput.style.webkitMaskSize = `${displayS}px ${displayS}px`; noteInput.style.maskSize = `${displayS}px ${displayS}px`;
      noteInput.style.webkitMaskRepeat = 'repeat'; noteInput.style.maskRepeat = 'repeat';
      
      noteInput.classList.add('dissolve-glitch-active');
      if (isStaticActive) noteInput.classList.add('static-fast-active'); else noteInput.classList.remove('static-fast-active');
    } else {
      noteInput.style.webkitMaskImage = 'none'; noteInput.style.maskImage = 'none';
      noteInput.classList.remove('dissolve-glitch-active', 'static-fast-active');
    }

    // Aplicar la nueva distorsión VHS Orgánica
    if (isCrtActive && jitterVal > 0) {
      noteInput.style.setProperty('--vhs-amt', jitterVal * 0.2); 
      noteInput.classList.add('vhs-distortion-active'); 
    } else { 
      noteInput.classList.remove('vhs-distortion-active'); 
    }
  }

  function updateBoxStyle() {
    const opacityVal = parseInt(boxOpacitySlider.value);
    valBoxOpacity.textContent = `${opacityVal}%`;
    const opacityRatio = opacityVal / 100;

    if (opacityRatio === 0) {
      noteWindow.style.background = 'transparent'; noteWindow.style.backdropFilter = 'none';
      noteWindow.style.border = 'none'; noteWindow.style.maskImage = 'none'; noteWindow.style.webkitMaskImage = 'none'; 
      updateBoxShadow(); return;
    }

    let backgroundStyle = '';
    const posVal = parseInt(gradPosSlider.value); valGradPos.textContent = posVal;

    if (gradientToggle.checked) {
      const rgb1 = `rgba(${gradR1.value}, ${gradG1.value}, ${gradB1.value}, ${opacityRatio})`;
      const rgb2 = `rgba(${gradR2.value}, ${gradG2.value}, ${gradB2.value}, ${opacityRatio})`;
      if (currentGradStyle === 'linear') backgroundStyle = `linear-gradient(${posVal}deg, ${rgb1}, ${rgb2})`;
      else if (currentGradStyle === 'radial') backgroundStyle = `radial-gradient(circle at ${posVal * 100 / 360}% center, ${rgb1}, ${rgb2})`;
      else if (currentGradStyle === 'center') backgroundStyle = `conic-gradient(from ${posVal}deg at center, ${rgb1}, ${rgb2}, ${rgb1})`;
    } else {
      backgroundStyle = `rgba(${glassR.value}, ${glassG.value}, ${glassB.value}, ${opacityRatio})`;
    }
    noteWindow.style.background = backgroundStyle;
    noteWindow.style.backdropFilter = 'blur(16px)';
    noteWindow.style.border = '1px solid rgba(255, 255, 255, 0.2)';

    const dirVal = parseInt(fadeDirSlider.value); valFadeDir.textContent = dirVal;
    const rangeVal = parseInt(fadeRangeSlider.value); valFadeRange.textContent = rangeVal;
    const intensityVal = parseInt(fadeIntensitySlider.value); valFadeIntensity.textContent = intensityVal;

    if (fadeToggle.checked) {
      const intRatio = intensityVal / 100;
      let maskStyle = currentFadeStyle === 'linear' 
        ? `linear-gradient(${dirVal}deg, rgba(0,0,0,${intRatio}) 0%, rgba(0,0,0,1) ${rangeVal}%)`
        : `radial-gradient(circle, rgba(0,0,0,1) 0%, rgba(0,0,0,${intRatio}) ${rangeVal}%)`;
      noteWindow.style.maskImage = maskStyle; noteWindow.style.webkitMaskImage = maskStyle;
    } else {
      noteWindow.style.maskImage = 'none'; noteWindow.style.webkitMaskImage = 'none';
    }
    updateBoxShadow();
  }

  function updateBoxShadow() {
    const spreadVal = parseInt(shadowSpread.value); valShadowSpread.textContent = `${spreadVal}px`;
    const blurVal = shadowBlur.value; valShadowBlur.textContent = `${blurVal}px`;
    
    let shadowString = 'none';
    let curvedInset = '';

    // ILUSIÓN DE PANTALLA CURVA: Sombras internas profundas en los bordes laterales
    if (warpToggle.checked && currentWarpStyle === 'curve') {
        const intensity = parseInt(warpIntensity.value) / 100;
        curvedInset = `inset 40px 0 50px -20px rgba(0,0,0,${0.6 * intensity}), inset -40px 0 50px -20px rgba(0,0,0,${0.6 * intensity})`;
    }

    if (shadowToggle.checked && spreadVal > 0) { 
      let shadowColor = `rgba(${shadowR.value}, ${shadowG.value}, ${shadowB.value}, 0.55)`;
      if (fadeToggle.checked) shadowColor = `rgba(${shadowR.value}, ${shadowG.value}, ${shadowB.value}, ${0.55 * (1 - parseInt(fadeIntensitySlider.value) / 100)})`;
      
      let dropShadow = `0px 0px ${blurVal}px ${spreadVal}px ${shadowColor}`;
      
      // Combinamos la sombra exterior del bloc con la sombra interior del efecto curvo
      shadowString = curvedInset ? `${dropShadow}, ${curvedInset}` : dropShadow;
    } else if (curvedInset) {
      shadowString = curvedInset;
    }

    noteWindow.style.boxShadow = shadowString;
  }

  function updateTransformations() {
    const scaleVal = parseInt(boxScaleSlider.value); valBoxScale.textContent = `${scaleVal}%`;
    const posX = boxPosX.value; valBoxPosX.textContent = `${posX}px`;
    const posY = boxPosY.value; valBoxPosY.textContent = `${posY}px`;
    const intensity = parseInt(warpIntensity.value); valWarpIntensity.textContent = `${intensity}%`;

    let transformString = `translate(${posX}px, ${posY}px) scale(${scaleVal / 100})`;
    
    if (warpToggle.checked) {
      const factor = intensity / 40;
      if (currentWarpStyle === 'arc') {
          transformString += ` perspective(500px) rotateX(${parseInt(warpX.value) + factor * 25}deg) rotateY(${warpY.value}deg) rotateZ(${warpZ.value}deg) scale(${1 + factor * 0.08})`;
      } 
      else if (currentWarpStyle === 'curve') {
          // ILUSIÓN DE PANTALLA CURVA
          const stretch = 1 + (factor * 0.15); 
          transformString += ` perspective(400px) rotateX(${parseInt(warpX.value) - 5}deg) rotateY(${warpY.value}deg) rotateZ(${warpZ.value}deg) scaleX(${stretch}) scaleY(1)`;
      }
    }
    noteWindow.style.transform = transformString;
  }

  // LISTENERS DE EVENTOS
  [textR, textG, textB, fontWeightSlider, strokeToggle, strokeColor, strokeWidthSlider, chromaticToggle, chromaticSlider, tshadowToggle, tshadowDepthSlider, tshadowBlurSlider, tshadowAngleSlider, tshadowColor, staticToggle, staticGrainSlider, staticBlendSlider, dissolveToggle, dissolveSizeSlider, dissolveStretchSlider, dissolveFadeSlider, crtToggle, crtScanlineSlider, crtJitterSlider].forEach(el => { el.addEventListener('input', updateTextStyling); el.addEventListener('change', updateTextStyling); });
  [glassR, glassG, glassB, boxOpacitySlider, gradientToggle, gradR1, gradG1, gradB1, gradR2, gradG2, gradB2, gradPosSlider, fadeToggle, fadeDirSlider, fadeRangeSlider, fadeIntensitySlider].forEach(el => { el.addEventListener('input', updateBoxStyle); el.addEventListener('change', updateBoxStyle); });
  [shadowToggle, shadowR, shadowG, shadowB, shadowSpread, shadowBlur].forEach(el => { el.addEventListener('input', updateBoxShadow); el.addEventListener('change', updateBoxShadow); });
  [boxScaleSlider, boxPosX, boxPosY, warpX, warpY, warpZ, warpIntensity].forEach(el => { el.addEventListener('input', updateTransformations); el.addEventListener('change', updateTransformations); });

  warpToggle.addEventListener('change', () => {
    updateTransformations();
    updateBoxShadow(); 
  });

  gradBtns.forEach(btn => { btn.addEventListener('click', () => { gradBtns.forEach(b => b.classList.remove('active')); btn.classList.add('active'); currentGradStyle = btn.getAttribute('data-style'); updateBoxStyle(); }); });
  fadeBtns.forEach(btn => { btn.addEventListener('click', () => { fadeBtns.forEach(b => b.classList.remove('active')); btn.classList.add('active'); currentFadeStyle = btn.getAttribute('data-style'); updateBoxStyle(); }); });
  
  warpBtns.forEach(btn => { 
    btn.addEventListener('click', () => { 
      warpBtns.forEach(b => b.classList.remove('active')); 
      btn.classList.add('active'); 
      currentWarpStyle = btn.getAttribute('data-style'); 
      updateTransformations(); 
      updateBoxShadow(); 
    }); 
  });
  
  shapeBtns.forEach(btn => { btn.addEventListener('click', () => { shapeBtns.forEach(b => b.classList.remove('active')); btn.classList.add('active'); noteWindow.classList.remove('shape-rounded', 'shape-square', 'shape-circle'); noteWindow.classList.add(btn.getAttribute('data-shape')); }); });

  fontSizeSlider.addEventListener('input', (e) => { valFontSize.textContent = `${e.target.value}px`; noteInput.style.fontSize = `${e.target.value}px`; });
  
  // SOLUCIÓN AL BUG DE ALINEACIÓN
  alignSelectEl.addEventListener('change', (e) => { 
    noteInput.classList.remove('align-center', 'align-left', 'align-right');
    noteInput.classList.add(`align-${e.target.value}`);
  });

  // Botones Reset
  document.querySelectorAll('.reset-btn, .reset-btn-text').forEach(btn => {
    btn.addEventListener('click', () => {
      const section = btn.getAttribute('data-reset');
      if (section === 'text') { 
        textR.value = 255; textG.value = 255; textB.value = 255; 
        fontSizeSlider.value = 14; valFontSize.textContent = "14px"; noteInput.style.fontSize = "14px";
        fontWeightSlider.value = 700; valFontWeight.textContent = "700"; noteInput.style.fontWeight = "700";
        strokeToggle.checked = false; strokeColor.value = "#000000"; strokeWidthSlider.value = 1; valStrokeWidth.textContent = "1";
        
        // SOLUCIÓN AL BUG EN EL RESET DE TEXTO
        alignSelectEl.value = "center";
        noteInput.classList.remove('align-center', 'align-left', 'align-right');
        noteInput.classList.add('align-center');
        
        updateTextStyling(); 
      }
      else if (section === 'texteffects') { 
        chromaticToggle.checked = false; chromaticSlider.value = 0; 
        tshadowToggle.checked = false; tshadowDepthSlider.value = 5; tshadowBlurSlider.value = 5; tshadowAngleSlider.value = 45; tshadowColor.value = '#000000';
        staticToggle.checked = false; staticGrainSlider.value = 1.5; staticBlendSlider.value = 50; 
        dissolveToggle.checked = false; dissolveSizeSlider.value = 2; dissolveStretchSlider.value = 1; dissolveFadeSlider.value = 0; 
        crtToggle.checked = false; crtScanlineSlider.value = 2; crtJitterSlider.value = 0;
        updateTextStyling(); 
      }
      else if (section === 'box') { 
        shapeBtns.forEach(b => b.classList.remove('active')); shapeBtns[0].classList.add('active'); noteWindow.classList.remove('shape-rounded', 'shape-square', 'shape-circle'); noteWindow.classList.add('shape-rounded'); 
        glassR.value = 0; glassG.value = 0; glassB.value = 0; boxOpacitySlider.value = 50; 
        gradientToggle.checked = false; gradR1.value = 20; gradG1.value = 20; gradB1.value = 35; gradR2.value = 100; gradG2.value = 50; gradB2.value = 200; gradPosSlider.value = 45; 
        fadeToggle.checked = false; fadeDirSlider.value = 90; fadeRangeSlider.value = 100; fadeIntensitySlider.value = 0; 
        shadowToggle.checked = true; shadowR.value = 255; shadowG.value = 255; shadowB.value = 255; shadowSpread.value = 3; shadowBlur.value = 10; 
        updateBoxStyle(); updateBoxShadow();
      }
      else if (section === 'layout') { 
        boxScaleSlider.value = 100; boxPosX.value = 0; boxPosY.value = 0; 
        warpToggle.checked = false; warpX.value = 0; warpY.value = 0; warpZ.value = 0; warpIntensity.value = 50;
        updateTransformations(); 
      }
    });
  });

  // Init
  updateTextStyling(); updateBoxStyle(); updateBoxShadow(); updateTransformations();
});
