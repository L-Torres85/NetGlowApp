document.addEventListener('DOMContentLoaded', () => {
  const appContainer = document.getElementById('app-container');
  const widgetBtn = document.getElementById('widget-mode-btn');
  const noteWindow = document.getElementById('note-window');
  const killSwitch = document.getElementById('kill-switch-btn');
  const noteInput = document.getElementById('note-input');
  const topBar = document.querySelector('.top-bar');
  const controlPanel = document.querySelector('.control-panel');
  let isWidgetMode = false;

  // -- Pestañas --
  const navBtns = document.querySelectorAll('.nav-btn');
  navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-btn, .settings-group').forEach(el => el.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.getAttribute('data-cat')).classList.add('active');
    });
  });

  // -- Lógica de Widget (Con Auto-Ajuste de Tamaño real) --
  widgetBtn.addEventListener('click', () => {
    isWidgetMode = true;
    appContainer.classList.replace('editor-mode', 'widget-mode');
    topBar.style.display = 'none'; controlPanel.style.display = 'none';
    noteInput.style.pointerEvents = 'none'; // Bloquea teclado emergente
    if (window.AndroidBridge) {
      const rect = noteWindow.getBoundingClientRect();
      window.AndroidBridge.cambiarTamano(true, Math.ceil(rect.width) + 30, Math.ceil(rect.height) + 30);
    }
  });

  noteWindow.addEventListener('dblclick', () => {
    if (!isWidgetMode) return;
    isWidgetMode = false;
    appContainer.classList.replace('widget-mode', 'editor-mode');
    topBar.style.display = ''; controlPanel.style.display = '';
    noteInput.style.pointerEvents = 'auto'; // Desbloquea teclado
    if (window.AndroidBridge) window.AndroidBridge.cambiarTamano(false, 0, 0);
  });

  killSwitch.addEventListener('click', (e) => { e.stopPropagation(); if (window.AndroidBridge) window.AndroidBridge.cerrarApp(); });

  // -- MOTOR DE TEXTO (Sólido, Degradado, Neón, Contorno) --
  const textR = document.getElementById('text-r'), textG = document.getElementById('text-g'), textB = document.getElementById('text-b');
  const fontSize = document.getElementById('font-size-slider'), fontWeight = document.getElementById('font-weight-slider'), align = document.getElementById('align-select');
  const strokeToggle = document.getElementById('stroke-toggle'), strokeColor = document.getElementById('stroke-color'), strokeWidth = document.getElementById('stroke-width-slider');
  const gradToggle = document.getElementById('text-grad-toggle'), gradC1 = document.getElementById('text-grad-c1'), gradC2 = document.getElementById('text-grad-c2');
  const glowColor = document.getElementById('text-glow-color'), glowBlur = document.getElementById('text-glow-blur');

  function updateText() {
    noteInput.style.fontSize = fontSize.value + 'px';
    noteInput.style.fontWeight = fontWeight.value;
    noteInput.style.textAlign = align.value;

    const solidColor = `rgb(${textR.value}, ${textG.value}, ${textB.value})`;
    
    // Degradado vs Color Sólido
    if (gradToggle.checked) {
      noteInput.style.backgroundImage = `linear-gradient(45deg, ${gradC1.value}, ${gradC2.value})`;
      noteInput.style.webkitBackgroundClip = 'text';
      noteInput.style.webkitTextFillColor = 'transparent';
      noteInput.style.color = 'transparent';
    } else {
      noteInput.style.backgroundImage = 'none';
      noteInput.style.webkitBackgroundClip = 'initial';
      noteInput.style.webkitTextFillColor = solidColor;
      noteInput.style.color = solidColor;
    }

    // Contorno (Stroke) arreglado
    if (strokeToggle.checked) {
      document.getElementById('val-stroke-width').innerText = strokeWidth.value + 'px';
      noteInput.style.webkitTextStroke = `${strokeWidth.value}px ${strokeColor.value}`;
    } else {
      noteInput.style.webkitTextStroke = '0px transparent';
    }

    // Brillo Neón (Optimizado por rendimiento)
    const blur = glowBlur.value;
    document.getElementById('val-text-glow').innerText = blur + 'px';
    if (blur > 0) {
      // Usamos drop-shadow directamente en la caja contenedora en vez de text-shadow para que funcione con el degradado sin laguear
      noteInput.style.filter = `drop-shadow(0px 0px ${blur}px ${glowColor.value})`;
    } else {
      noteInput.style.filter = 'none';
    }
  }
  [textR, textG, textB, fontSize, fontWeight, align, strokeToggle, strokeColor, strokeWidth, gradToggle, gradC1, gradC2, glowColor, glowBlur].forEach(el => el.addEventListener('input', updateText));

  // -- MOTOR DEL BLOC (Forma, Cristal, Degradado, Sombra Fija) --
  const shapeBtns = document.querySelectorAll('.option-btn[data-shape]');
  const glassR = document.getElementById('glass-r'), glassG = document.getElementById('glass-g'), glassB = document.getElementById('glass-b'), opacity = document.getElementById('box-opacity-slider');
  const bgGradToggle = document.getElementById('gradient-toggle'), bgR1 = document.getElementById('grad-r1'), bgG1 = document.getElementById('grad-g1'), bgB1 = document.getElementById('grad-b1'), bgR2 = document.getElementById('grad-r2'), bgG2 = document.getElementById('grad-g2'), bgB2 = document.getElementById('grad-b2');
  const shadowToggle = document.getElementById('shadow-toggle'), shadowSpread = document.getElementById('shadow-spread'), shadowBlur = document.getElementById('shadow-blur');

  shapeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      shapeBtns.forEach(b => b.classList.remove('active')); btn.classList.add('active');
      noteWindow.className = `note-window ${btn.getAttribute('data-shape')}`;
    });
  });

  function updateBloc() {
    const op = opacity.value / 100;
    document.getElementById('val-box-opacity').innerText = opacity.value + '%';
    
    if (bgGradToggle.checked) {
      noteWindow.style.background = `linear-gradient(45deg, rgba(${bgR1.value},${bgG1.value},${bgB1.value},${op}), rgba(${bgR2.value},${bgG2.value},${bgB2.value},${op}))`;
    } else {
      noteWindow.style.background = `rgba(${glassR.value}, ${glassG.value}, ${glassB.value}, ${op})`;
    }

    if (shadowToggle.checked) {
      noteWindow.style.boxShadow = `0px 10px ${shadowBlur.value}px ${shadowSpread.value}px rgba(0,0,0,0.5)`;
    } else {
      noteWindow.style.boxShadow = 'none';
    }
  }
  [glassR, glassG, glassB, opacity, bgGradToggle, bgR1, bgG1, bgB1, bgR2, bgG2, bgB2, shadowToggle, shadowSpread, shadowBlur].forEach(el => el.addEventListener('input', updateBloc));

  // -- MOTOR 3D --
  const scaleSlider = document.getElementById('box-scale-slider'), posX = document.getElementById('box-pos-x'), posY = document.getElementById('box-pos-y');
  const warpToggle = document.getElementById('warp-toggle'), warpX = document.getElementById('warp-x'), warpY = document.getElementById('warp-y'), warpZ = document.getElementById('warp-z');

  function update3D() {
    let transform = `scale(${scaleSlider.value / 100}) translate(${posX.value}px, ${posY.value}px)`;
    if (warpToggle.checked) {
      transform += ` rotateX(${warpX.value}deg) rotateY(${warpY.value}deg) rotateZ(${warpZ.value}deg)`;
    }
    noteWindow.style.transform = transform;
  }
  [scaleSlider, posX, posY, warpToggle, warpX, warpY, warpZ].forEach(el => el.addEventListener('input', update3D));

  // Inicializar
  updateText(); updateBloc(); update3D();
});
