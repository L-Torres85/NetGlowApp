package com.noteglow.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class FloatingNoteService extends Service {
    private WindowManager windowManager;
    private WebView webView;
    private WindowManager.LayoutParams params;
    private boolean isWidgetMode = false; 

    public class WebAppInterface {
        // NUEVO: Ahora recibe el ANCHO y ALTO exactos desde la página web
        @JavascriptInterface
        public void cambiarTamano(boolean modoWidget, int anchoWeb, int altoWeb) {
            isWidgetMode = modoWidget; 
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    if (modoWidget) {
                        // Multiplicamos por la densidad para convertir medidas web a medidas de pantalla real
                        float density = getResources().getDisplayMetrics().density;
                        params.width = (int) (anchoWeb * density);
                        params.height = (int) (altoWeb * density); 
                    } else {
                        params.width = WindowManager.LayoutParams.MATCH_PARENT; 
                        params.height = 1800; 
                    }
                    windowManager.updateViewLayout(webView, params);
                }
            });
        }

        @JavascriptInterface
        public void cerrarApp() {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    stopSelf(); 
                }
            });
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        webView = new WebView(this);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        
        webView.setBackgroundColor(0x00000000); 
        webView.setWebChromeClient(new WebChromeClient());
        
        webView.addJavascriptInterface(new WebAppInterface(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");

        int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O 
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY 
            : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                1800, 
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = 100; 

        webView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean isLongPress = false;
            private Handler handler = new Handler(Looper.getMainLooper());
            private Runnable longPressRunnable = new Runnable() {
                @Override
                public void run() {
                    isLongPress = true; 
                }
            };

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (!isWidgetMode) {
                    return false; 
                }

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        isLongPress = false;
                        initialX = params.x; initialY = params.y;
                        initialTouchX = event.getRawX(); initialTouchY = event.getRawY();
                        handler.postDelayed(longPressRunnable, 500); 
                        return false; 
                        
                    case MotionEvent.ACTION_MOVE:
                        float dx = Math.abs(event.getRawX() - initialTouchX);
                        float dy = Math.abs(event.getRawY() - initialTouchY);
                        if (!isLongPress && (dx > 15 || dy > 15)) {
                            handler.removeCallbacks(longPressRunnable);
                        }
                        if (isLongPress) {
                            params.x = initialX + (int) (event.getRawX() - initialTouchX);
                            params.y = initialY + (int) (event.getRawY() - initialTouchY);
                            windowManager.updateViewLayout(webView, params);
                            return true;
                        }
                        return false;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        handler.removeCallbacks(longPressRunnable);
                        if (isLongPress) {
                            isLongPress = false;
                            return true;
                        }
                        return false;
                }
                return false;
            }
        });

        windowManager.addView(webView, params);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (webView != null) windowManager.removeView(webView);
    }
}
